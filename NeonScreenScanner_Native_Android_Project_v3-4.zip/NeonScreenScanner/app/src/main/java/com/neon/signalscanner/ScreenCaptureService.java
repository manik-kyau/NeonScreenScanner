package com.neon.signalscanner;

import android.app.*;import android.content.*;import android.content.pm.ServiceInfo;import android.graphics.PixelFormat;import android.hardware.display.*;import android.media.*;import android.media.projection.*;import android.os.*;import android.content.res.Resources;import java.nio.ByteBuffer;

public class ScreenCaptureService extends Service {
 private MediaProjection projection;private VirtualDisplay display;private ImageReader reader;private Handler handler;private int width,height;
 private static final int NOTIFICATION_ID=31,INTERVAL_MS=900;private static final String CHANNEL="neon_scan";
 @Override public void onCreate(){super.onCreate();handler=new Handler(Looper.getMainLooper());createChannel();}
 @Override public int onStartCommand(Intent intent,int flags,int startId){
  startAsForeground(); if(intent==null)return START_NOT_STICKY; int rc=intent.getIntExtra("resultCode",Activity.RESULT_CANCELED); Intent data=getIntentExtra(intent,"data");
  if(projection==null && data!=null){MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);begin(m.getMediaProjection(rc,data));} return START_NOT_STICKY;
 }
 @SuppressWarnings("deprecation") private Intent getIntentExtra(Intent i,String key){if(Build.VERSION.SDK_INT>=33)return i.getParcelableExtra(key,Intent.class);return i.getParcelableExtra(key);}
 private void startAsForeground(){Notification n=notification();if(Build.VERSION.SDK_INT>=29)startForeground(NOTIFICATION_ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(NOTIFICATION_ID,n);}
 private void begin(MediaProjection p){if(p==null){stopSelf();return;}projection=p;projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}},handler);
  width=Resources.getSystem().getDisplayMetrics().widthPixels;height=Resources.getSystem().getDisplayMetrics().heightPixels;int density=Resources.getSystem().getDisplayMetrics().densityDpi;
  reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,2);reader.setOnImageAvailableListener(r->{Image im=null;try{im=r.acquireLatestImage();if(im!=null)analyze(im);}finally{if(im!=null)im.close();}},handler);
  display=projection.createVirtualDisplay("NeonScreenScanner",width,height,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
 }
 private void analyze(Image image){Image.Plane p=image.getPlanes()[0];ByteBuffer b=p.getBuffer();int ps=p.getPixelStride(),rs=p.getRowStride();int ys=(int)(height*.18),ye=(int)(height*.88),step=Math.max(8,width/180);long g=0,r=0,total=0;
  for(int y=ys;y<ye;y+=step)for(int x=0;x<width;x+=step){int pos=y*rs+x*ps;if(pos+3>=b.limit())continue;int R=b.get(pos)&255,G=b.get(pos+1)&255,B=b.get(pos+2)&255;total++;if(G>125&&G>R*1.18&&G>B*1.08&&G-R>35)g++;else if(R>125&&R>G*1.18&&R>B*1.08&&R-G>35)r++;}
  if(total==0)return;double gp=g*100.0/total,rp=r*100.0/total,bias=gp-rp;String trend=bias>.10?"BULLISH":bias<-.10?"BEARISH":"NEUTRAL";String sig="WAIT";int conf=50;
  if(gp+rp>.8&&bias>.18){sig="CALL";conf=Math.min(88,60+(int)(bias*45));}else if(gp+rp>.8&&bias<-.18){sig="PUT";conf=Math.min(88,60+(int)(-bias*45));}
  Intent out=new Intent("com.neon.signalscanner.RESULT");out.setPackage(getPackageName());out.putExtra("signal",sig);out.putExtra("confidence",conf);out.putExtra("details","Green pixels: "+String.format("%.2f",gp)+"%\nRed pixels: "+String.format("%.2f",rp)+"%\nFrame trend: "+trend+"\nQuality: "+String.format("%.1f",Math.min(100,(gp+rp)*50))+"%");sendBroadcast(out);
 }
 private Notification notification(){PendingIntent pi=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,CHANNEL).setContentTitle("Neon Signal Bot").setContentText("Quotex screen scanner is running").setSmallIcon(android.R.drawable.ic_menu_view).setContentIntent(pi).setOngoing(true).build();}
 private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Neon Screen Scanner",NotificationManager.IMPORTANCE_LOW));}}
 @Override public void onDestroy(){if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
