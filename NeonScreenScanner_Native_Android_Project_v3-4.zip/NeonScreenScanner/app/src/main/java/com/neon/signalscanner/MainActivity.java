package com.neon.signalscanner;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final int CAPTURE_REQUEST=9001;
    private TextView state,signal,confidence,details;
    private Button start,stop;
    private MediaProjectionManager projectionManager;
    private final BroadcastReceiver receiver=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){
            if(!"com.neon.signalscanner.RESULT".equals(i.getAction())) return;
            String s=i.getStringExtra("signal"); int conf=i.getIntExtra("confidence",0);
            signal.setText(s); confidence.setText("Confidence: "+conf+"%"); details.setText(i.getStringExtra("details"));
            if("CALL".equals(s)) signal.setTextColor(Color.rgb(0,255,183));
            else if("PUT".equals(s)) signal.setTextColor(Color.rgb(255,80,100));
            else signal.setTextColor(Color.rgb(255,211,77));
        }
    };

    @Override protected void onCreate(Bundle b){super.onCreate(b);buildUi();
        projectionManager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},700);
        start.setOnClickListener(v->requestCapture());
        stop.setOnClickListener(v->{stopService(new Intent(this,ScreenCaptureService.class));setRunning(false);});
    }
    @Override protected void onStart(){super.onStart();registerReceiver(receiver,new IntentFilter("com.neon.signalscanner.RESULT"),Context.RECEIVER_NOT_EXPORTED);}
    @Override protected void onStop(){unregisterReceiver(receiver);super.onStop();}
    private void requestCapture(){startActivityForResult(projectionManager.createScreenCaptureIntent(),CAPTURE_REQUEST);}
    @Override protected void onActivityResult(int r,int code,Intent data){super.onActivityResult(r,code,data);
        if(r==CAPTURE_REQUEST && code==Activity.RESULT_OK && data!=null){
            Intent s=new Intent(this,ScreenCaptureService.class);s.putExtra("resultCode",code);s.putExtra("data",data);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);setRunning(true);
        }else state.setText("SCREEN PERMISSION CANCELLED");
    }
    private void setRunning(boolean x){start.setEnabled(!x);stop.setEnabled(x);state.setText(x?"SCANNING QUOTEX SCREEN…":"READY");state.setTextColor(Color.parseColor(x?"#00FFB7":"#A7BDCA"));}
    private void buildUi(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(18,18,18,18);root.setBackgroundColor(Color.parseColor("#030711"));
        root.addView(tv("⚡ NEON SIGNAL BOT",25,Color.WHITE),lp(-1,-2,0));
        root.addView(tv("QUOTEX SCREEN SCANNER • REAL MARKET • ANALYSIS ONLY",12,Color.parseColor("#7897A9")),lp(-1,-2,0));
        state=tv("READY",14,Color.parseColor("#A7BDCA"));state.setPadding(0,28,0,18);root.addView(state,lp(-1,-2,0));
        signal=tv("WAIT",46,Color.rgb(255,211,77));signal.setGravity(Gravity.CENTER);root.addView(signal,lp(-1,100,0));
        confidence=tv("Confidence —",15,Color.WHITE);confidence.setGravity(Gravity.CENTER);root.addView(confidence,lp(-1,55,0));
        details=tv("Open Quotex first. Then press START and approve Android's screen-capture prompt.",13,Color.parseColor("#9AB2C0"));details.setPadding(8,16,8,16);root.addView(details,lp(-1,-2,1));
        start=new Button(this);start.setText("📺 START SCREEN SCAN");root.addView(start,lp(-1,60,0));
        stop=new Button(this);stop.setText("■ STOP SCAN");stop.setEnabled(false);root.addView(stop,lp(-1,60,0));
        root.addView(tv("\n⚠️ Screen analysis only. No trade execution. Signals are estimates from visible chart pixels and are not guaranteed.",11,Color.parseColor("#718B9A")),lp(-1,-2,0));setContentView(root);}
    private TextView tv(String s,int z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);return t;}
    private LinearLayout.LayoutParams lp(int w,int h,float weight){return new LinearLayout.LayoutParams(w,h,weight);}
}
